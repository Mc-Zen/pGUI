package pGUI.core;

import processing.core.*;

public class Label extends Control {

	public Label() {
		this("", 12);
	}

	public Label(String text) {
		this(text, 12);
	}

	public Label(String text, int fontSize) {
		super();
		this.setText(text);
		this.setFontSize(fontSize);
		borderWidth = 0;
		visualBackgroundColor = 0;
	}

	@Override
	protected void render() {

		drawDefaultBackground();
		drawDefaultText();

	}

	@Override
	protected void autosize() {
		pg = Frame.frame0.papplet.createGraphics(1, 1);
		pg.beginDraw();
		pg.textSize(fontSize);
		width = (int) PApplet.constrain(pg.textWidth(text) + 1, minWidth, maxWidth) + paddingLeft + paddingRight;
		height = (int) PApplet.constrain(fontSize + pg.textDescent(), minHeight, maxHeight) + paddingTop
				+ paddingBottom;
	}
}