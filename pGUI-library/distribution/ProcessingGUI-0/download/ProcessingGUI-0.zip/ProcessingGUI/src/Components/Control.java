package pGUI.core;

import processing.core.*;
import processing.event.*;
import java.lang.reflect.Method;

import java.lang.reflect.InvocationTargetException;
import pGUI.classes.*;

/*
 * Main component all other components inherit from. 
 * 
 * It provides all basic style attributes and methods. 
 * It also comes with the standard event handling. 
 * 
 */



public abstract class Control {

	/*
	 * Name for the element can be specified manually, useful for distinguishing.
	 * 
	 * This property has no effect on the looks.
	 */

	public String name = "";


	/*
	 * Parent container of this element. The Frame itself is the master container
	 * and every element that should be visible has to be a child of Frame in some
	 * nested way.
	 */
	protected Control parent;



	/*
	 * Image object that always contains the updated looks of this element. When
	 * parents are rendered they project the PGraphics of their children onto
	 * themselves. In this way only the changed parts have to be re-rendered and not
	 * the entire gui.
	 */
	protected PGraphics pg;




	/*
	 * changedVisuals will be set to true when graphics of this control changed, so
	 * parents know if they need to re-render this object.
	 * 
	 * This will happen when update() has been called for this Control (update()
	 * also calls update() for all parent containers)
	 * 
	 * Don't set this property, only call update() in your classes !
	 */

	protected boolean changedVisuals = true;


	/*
	 * type of control class, i.e. all containers are marked as such (needed for
	 * quick render decisions)
	 */

	protected int cType = DEFAULT;
	protected static final int DEFAULT = 0;
	protected static final int CONTAINER = 1;


	/*
	 * Status properties
	 */
	protected boolean focusable = true; // determines if this control can be focused at all
	protected boolean focused = false; // Dont'change focused from outside
	protected boolean stickyFocus = false; // when true than its focused state can't be overridden by other elements
											 // requesting focus, only when itself calls blur

	protected boolean enabled = true; // setting this to false prevents it from getting any mouse and key events
	protected boolean visible = true;


	/*
	 * Coordinates and size relative to container (won't be changed by
	 * flowContainer!).
	 */
	protected int x;
	protected int y;
	protected int z; // z-index of component, only has an effect when component is in a panel
					 // container
					 // (not a flow- or scroll container)

	protected int width;
	protected int height;

	protected int minWidth = 1;
	protected int maxWidth = 10000;
	protected int minHeight = 1;
	protected int maxHeight = 10000;

	protected int marginLeft;
	protected int marginTop;
	protected int marginRight;
	protected int marginBottom;

	protected int paddingLeft;
	protected int paddingRight;
	protected int paddingTop;
	protected int paddingBottom;


	/*
	 * Bounds are the key to the mouse event listening process. They describe the
	 * objects position and size relative to the window origin.
	 * 
	 * Containers set the bounds of their children after rendering. Don't change
	 * them manually!
	 */

	protected Bounds bounds = new Bounds(0, 0, 0, 0);


	/*
	 * Visuals
	 */
	protected String text = ""; // multi-purpose text to display, e.g. button text, label text, textbox content
	protected int fontSize;
	protected int textAlign = 3; // LEFT, CENTER, RIGHT (= 37, 3, 39) from PConstants
	protected int textAlignY = 3; // vertical text align (TOP, CENTER, BOTTOM) (= 101, 3, 102)

	protected int backgroundType = COLOR; // mode to fill background, default Color
	public static final int COLOR = 0; // use color to draw background
	public static final int IMAGE = 1; // use image to draw background

	protected PImage image;
	protected int imageMode = FILL;


	/*
	 * IMAGE MODES:
	 * 
	 * FILL: distort image if necessary
	 * 
	 * FIT:enlarge image so it fills out entire object centered, parts of the image
	 * might be hidden; fits the larger side
	 * 
	 * FIT_INSIDE: place image centered in the object without cropping it, so it
	 * fits the smaller side
	 */

	public static final int FILL = 1;
	public static final int FIT = 2;
	public static final int FIT_INSIDE = 3;

	protected int backgroundColor;
	protected int foregroundColor;
	protected int borderColor;
	protected int hoverColor; // first set automatically with backgroundColor, can be changed programatically
	protected int pressedColor; // first set automatically with backgroundColor, can be changed programatically

	protected int visualBackgroundColor; // actually displayed color, usually = BackgroundColor, except when hover or

	protected int borderWidth;
	protected int borderRadius;
	protected int cursor;

	protected int opacity = 100; // opacity in percent (1-100)


	/*
	 * Events
	 */

	// previous hovered/pressed state
	protected boolean pHovered = false;
	protected boolean pPressed = false;




	/*
	 * if true then shortcuts registered to frame won't be handled if this element
	 * is focused. I.e. useful for textboxes (ctrl-c, x etc.)
	 */

	protected boolean overridesParentsShortcuts = false;






	public Control() {

		height = 50;
		width = 50;

		backgroundColor = 255;
		visualBackgroundColor = 255;
		foregroundColor = 0;
		borderColor = 20;
		hoverColor = 200;
		pressedColor = 150;

		fontSize = 15;
		setupListeners(0);
	}







	protected void initialize() {

	}




	/*
	 * DRAWING AND RENDERING
	 */

	/*
	 * This method has to be implemented by all container classes. Containers have
	 * to set their childrens bounds in respect to their own.
	 * 
	 * Bounds are always relative to the window origin If a child is a container
	 * itself (child.cType == CONTAINER) its calcBounds()-method has to be called
	 * too.
	 */

	protected void calcBounds() {
	};

	/*
	 * Main drawing method that determines the looks of the object.
	 * 
	 * It has to be implemented for each control individually. Just start with
	 * something like:
	 * 
	 * pg.rect(...); pg.line(...) ...
	 * 
	 * , using the standard drawing funcions. It is not necessary to create the
	 * PGraphics object nor to call beginDraw() or endDraw() as you are maybe used
	 * to.
	 * 
	 * You can call the drawDefaultBackgrond() and drawDefaultText() methods which
	 * do the standard drawing of text and background while paying attention to
	 * attributes like backgroundColor, borderColor, borderWidth, image, imageMode,
	 * ..., textAlign, fontColor, fontSize.
	 * 
	 */

	protected abstract void render();



	/*
	 * Dimensions (width, height) from previous frame. Used to check if size
	 * changed. If so the PGraphics needs to be created new
	 */

	protected int pWidth, pHeight = -1;

	/*
	 * Method to executed by the parent container before calling render(). It
	 * prepares the PGraphics for rendering
	 */

	protected final void preRender() {
		// only create graphics when size changed
		if (width != pWidth || height != pHeight) {
			pg = Frame.frame0.papplet.createGraphics(width, height);
			pWidth = width;
			pHeight = height;
			pg.beginDraw();
		} else {
			pg.beginDraw();
			pg.clear();
		}
	}

	// just return the looks of this control, without drawing
	protected PImage getGraphics() {
		return pg;
	}

	/*
	 * Call parent to update and set flag that this control has changed its looks.
	 * In the next frame elements that have changed get the chance to redraw
	 * themselves. (normally the render() method is not called every frame)
	 */

	protected void update() {
		if (parent != null) {
			changedVisuals = true;
			parent.update();
		}
	}

	/*
	 * enable the programmer to force a re-render. This shouldn't be needed, but
	 * just in case
	 */
	public void forceRenderAlthoughItShouldntBeNeeded() {
		update();
	}







	/*
	 * Request the Frame object to focus/blur this object. The Frame decides upon
	 * the demand and sets the elements focused state to true. There can only be one
	 * focused element at a time and it is stored in the Frames property
	 * "focusedElement".
	 */

	public void focus() {
		Frame.frame0.requestFocus(this);
	}

	public void blur() {
		Frame.frame0.requestBlur(this);
	}

	// just a useful debugging function
	protected void drawBounds() {
		Frame.frame0.papplet.rect(bounds.X0, bounds.Y0, bounds.X - bounds.X0, bounds.Y - bounds.Y0);
	}






	/*
	 * Standard text drawing method accounting padding, align, color etc.
	 * 
	 * This method can be used by any control for drawing its text.
	 */

	protected void drawDefaultText() {
		pg.fill(foregroundColor);
		pg.textSize(fontSize);
		pg.textAlign(textAlign, textAlignY);
		int x = 0;
		int y = 0;

		switch (textAlign) {
		case 37:
			x = paddingLeft;
			break;
		case 3:
			x = (width - paddingRight - paddingLeft) / 2 + paddingLeft;
			break;
		case 39:
			x = width - paddingRight;
			break;
		}
		switch (textAlignY) {
		case 101:
			y = paddingTop;
			break;
		case 3:
			y = height / 2;
			break;
		case 102:
			y = height - paddingBottom;
			break;
		}
		pg.text(text, x, y);
	}



	/*
	 * Standard background drawing method - this method can be used by any control
	 */

	protected void drawDefaultBackground() {
		if (backgroundType == COLOR) {

			if (visualBackgroundColor != 0) {
				pg.fill(visualBackgroundColor);
				pg.strokeWeight(borderWidth);
				pg.stroke(borderWidth != 0 ? borderColor : visualBackgroundColor); // ensure that there's no nasty thin
																					 // border when borderwidth == 0
				pg.rect(borderWidth / 2, borderWidth / 2, width - borderWidth, height - borderWidth, borderRadius);
			}
		} else if (backgroundType == IMAGE) {

			if (imageMode == FILL) {
				pg.image(image, 0, 0, width, height);
			} else if (imageMode == FIT) {
				// mode FIT fills the entire background (without distortion) but without leaving
				// any blank parts
				if (image.width / image.height < width / height) {
					int newHeight = (int) (image.height / (float) image.width * width);
					pg.image(image, 0, -(newHeight - height) / 2, width, newHeight);
				} else {
					int newWidth = (int) (image.width / (float) image.height * height);
					pg.image(image, -(newWidth - width) / 2, 0, newWidth, height);
				}
			} else if (imageMode == FIT_INSIDE) {
				// mode FITINSIDE makes sure the entire image is visible without distortion;
				// usually results in blank parts
				if (image.width / image.height > width / height) {
					int newHeight = (int) (image.height / (float) image.width * width);
					pg.image(image, 0, -(newHeight - height) / 2, width, newHeight);
				} else {
					int newWidth = (int) (image.width / (float) image.height * height);
					pg.image(image, -(newWidth - width) / 2, 0, newWidth, height);
				}
			}

			// still draw border
			if (borderWidth > 0) {
				pg.noFill();
				pg.strokeWeight(borderWidth);
				pg.stroke(borderColor);
				pg.rect(borderWidth / 2, borderWidth / 2, width - borderWidth, height - borderWidth, borderRadius);
			}
		}
	}









	/*
	 * ANCHORS / AUTOMATIC�RESIZING
	 *
	 *
	 * 
	 * The usage of anchors allows to adapt size or keep fixed positions when a
	 * parent container changes in size. I.e. When the RIGHT anchor is set the
	 * control will keep the distance between its right edge and the right edge of
	 * the container (like a right align). When RIGHT and LEFT anchors are set both
	 * right and left edges will keep their distance to the container Bounds which
	 * results in a new size of this control.
	 * 
	 * The anchors-array is set to all MIN_VALUE per default. When an anchor is
	 * added it stores the distance from the top, bottom, left or right edge of this
	 * control to the according edge of the container. When the resize() function is
	 * called the anchors will be checked and applied.
	 *
	 * 
	 * The new size of the control will be constrained by minimal and maximal
	 * width/height obviously. If the new size cannot be fully attained the control
	 * will orient at the top left of the container.
	 * 
	 * 
	 */

	// the anchor array used to store the anchors data.
	// In following order: TOP, RIGHT, BOTTOM, LEFT:
	protected int anchors[] = { Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE };

	public static final int TOP_ANCHOR = 0;
	public static final int RIGHT_ANCHOR = 1;
	public static final int BOTTOM_ANCHOR = 2;
	public static final int LEFT_ANCHOR = 3;

	// used for quickly checking if anchors are set up at all.
	protected boolean usingAnchors = false;


	/*
	 * add an anchor (types are TOP, RIGHT, BOTTOM, LEFT) When adding the right or
	 * bottom anchor the distance to the containers bounds is stored.
	 */

	public void addAutoAnchor(int... newAnchors) {
		for (int anchor : newAnchors) {
			switch (anchor) {
			case PApplet.TOP:
				anchors[TOP_ANCHOR] = y;
				break;
			case PApplet.RIGHT:
				anchors[RIGHT_ANCHOR] = parent.width - width - x;
				break;
			case PApplet.BOTTOM:
				anchors[BOTTOM_ANCHOR] = parent.height - height - y;
				break;
			case PApplet.LEFT:
				anchors[LEFT_ANCHOR] = x;
				break;
			default:
				return;
			}
		}

		usingAnchors = true;
	}




	/*
	 * Not yet ready for users.
	 * 
	 * resize() needs to be called, so the changes that should be applied so the
	 * anchor is executed correctly need to be updated. On the other hand this needs
	 * the parent to be set.
	 */
	protected void setAnchor(int anchorType, int value) {
		if (anchorType >= 0 && anchorType < 4) {
			anchors[anchorType] = value;
		}
		usingAnchors = true;
		resize();

	}


	/*
	 * Calculate all set anchors new. Needed when position of this item has been
	 * changed through the setter
	 */

	protected void updateAnchors() {
		if (usingAnchors) {
			if (anchors[TOP_ANCHOR] != Integer.MIN_VALUE) {
				anchors[TOP_ANCHOR] = y;
			}
			if (anchors[RIGHT_ANCHOR] != Integer.MIN_VALUE) {
				anchors[RIGHT_ANCHOR] = parent.width - width - x;
			}
			if (anchors[BOTTOM_ANCHOR] != Integer.MIN_VALUE) {
				anchors[BOTTOM_ANCHOR] = parent.height - height - y;
			}
			if (anchors[LEFT_ANCHOR] != Integer.MIN_VALUE) {
				anchors[LEFT_ANCHOR] = x;
			}

		}
	}

	public void removeAnchor(int anchorType) {
		switch (anchorType) {
		case PApplet.TOP:
			anchors[TOP_ANCHOR] = Integer.MIN_VALUE;
			break;
		case PApplet.RIGHT:
			anchors[RIGHT_ANCHOR] = Integer.MIN_VALUE;
			break;
		case PApplet.BOTTOM:
			anchors[BOTTOM_ANCHOR] = Integer.MIN_VALUE;
			break;
		case PApplet.LEFT:
			anchors[LEFT_ANCHOR] = Integer.MIN_VALUE;
			break;
		}
		if (anchors[TOP_ANCHOR] == Integer.MIN_VALUE && anchors[RIGHT_ANCHOR] == Integer.MIN_VALUE && anchors[BOTTOM_ANCHOR] == Integer.MIN_VALUE
				&& anchors[LEFT_ANCHOR] == Integer.MIN_VALUE) {
			usingAnchors = false;
		}
	}



	/*
	 * Resize Event: if any anchors are set, either size or position of this control
	 * might need adjusting
	 */

	protected void resize() {
		if (usingAnchors) {
			if (anchors[RIGHT_ANCHOR] != Integer.MIN_VALUE) {
				if (anchors[LEFT_ANCHOR] != Integer.MIN_VALUE) { // also left anchor

					// don't use setter here, so not to call this method over and over
					width = Math.max(Math.min(parent.width - x - anchors[RIGHT_ANCHOR], maxWidth), minWidth);
				} else { // only right anchor
					x = parent.width - width - anchors[RIGHT_ANCHOR];
				}
			}
			if (anchors[BOTTOM_ANCHOR] != Integer.MIN_VALUE) {
				if (anchors[TOP_ANCHOR] != Integer.MIN_VALUE) { // also top anchor

					// don't use setter here, so not to call this method over and over
					height = Math.max(Math.min(parent.height - y - anchors[BOTTOM_ANCHOR], maxHeight), minHeight);
				} else { // only bottom anchor
					y = parent.height - height - anchors[BOTTOM_ANCHOR];
				}
			}
			update();
		}
	}




	/*
	 * Autosize specifies actions that will set width/height new, when padding,
	 * text, or fontSize changed. Each class can override it to specify custom
	 * calculations. 
	 */
	protected void autosize() {
	}





	/*
	 * Style Setter
	 */

	public void setX(int x) {
		this.x = x;
		if (usingAnchors)
			updateAnchors();
		update();
	}

	public void setY(int y) {
		this.y = y;
		if (usingAnchors)
			updateAnchors();
		update();
	}

	public void setZ(int z) {
		this.z = z;
		if (parent != null)
			try {
				// no use to sort containers with autolayout (its bad actually because it could
				// chang order
				if (!((Container) parent).autoLayout)
					((Container) parent).sortContent();
			} catch (ClassCastException cce) {

			}
		update();
	}

	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
		update();
	}

	public void setWidth(int width) {
		// constrain width immediately
		this.width = Math.max(Math.min(width, maxWidth), minWidth);
		// call the resize event.
		resize();
		update();
	}

	public void setMinWidth(int minWidth) {
		// don't allow width ever to go below 1 (that produces errors when creating
		// graphics)
		this.minWidth = Math.max(1, minWidth);
		autosize();
		update();
	}

	public void setMaxWidth(int maxWidth) {
		this.maxWidth = maxWidth;
		autosize();
		update();
	}

	public void setHeight(int height) {
		// constrain height immeditaly
		this.height = Math.max(Math.min(height, maxHeight), minHeight);
		resize();
		update();
	}

	public void setMinHeight(int minHeight) {
		// don't allow height ever to go below 1 (that produces errors when creating
		// graphics)
		this.minHeight = Math.max(1, minHeight);
		autosize();
		update();
	}

	public void setMaxHeight(int maxHeight) {
		this.maxHeight = maxHeight;
		autosize();
		update();
	}

	public void setSize(int width, int height) {
		// no setter used here so not to call resize twice
		this.width = Math.max(Math.min(width, maxWidth), minWidth);
		this.height = Math.max(Math.min(height, maxHeight), minHeight);
		resize();
		update();
	}

	public void setBackgroundColor(int clr) {
		backgroundColor = clr;
		visualBackgroundColor = clr;
		backgroundType = Control.COLOR;
		update();
	}

	// automatically generates hover and pressed color
	protected void setBackgroundColorsAutomatically(int clr) {
		backgroundColor = clr;
		visualBackgroundColor = clr;

		int r = (int) Frame.frame0.papplet.red(clr);
		int g = (int) Frame.frame0.papplet.green(clr);
		int b = (int) Frame.frame0.papplet.blue(clr);
		// int a = (int) papplet.alpha(clr);

		if (Frame.frame0.papplet.brightness(clr) > 40) { // darken color for HoverColor and PressedColor when color is
														 // bright enough
			hoverColor = Color.create(r - 20, g - 20, b - 20);
			pressedColor = Color.create(r - 40, g - 40, b - 40);
		} else { // lighten color for HoverColor and PressedColor when color too dark
			hoverColor = Color.create(r + 20, g + 20, b + 20);
			pressedColor = Color.create(r + 40, g + 40, b + 40);
		}
		backgroundType = Control.COLOR;
		update();
	}

	public void setForegroundColor(int clr) {
		foregroundColor = clr;
		update();
	}

	public void setHoverColor(int clr) {
		this.hoverColor = clr;
		update();
	}

	public void setPressedColor(int clr) {
		this.pressedColor = clr;
		update();
	}

	public void setBorderColor(int clr) {
		borderColor = clr;
		update();
	}

	public void setBorderWidth(int borderWidth) {
		this.borderWidth = Math.max(0, borderWidth);
		update();
	}

	public void setBorderRadius(int borderRadius) {
		this.borderRadius = borderRadius;
	}

	public void setText(String text) {
		this.text = text;
		autosize();
		update();
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
		autosize();
		update();
	}

	public void setTextAlign(int align) {
		if (align == 3 || align == 37 || align == 39)
			this.textAlign = align;
	}

	public void setTextAlignY(int align) {
		if (align == 3 || align == 101 || align == 102)
			this.textAlignY = align;
	}

	public void setCursor(int cursor) {
		if (cursor >= 0 && cursor < 12) {
			this.cursor = cursor;
		}
	}

	public void setImage(PImage image) {
		try {
			this.image = (PImage) image.clone();
			backgroundType = Control.IMAGE;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setImageMode(int imageMode) {
		this.imageMode = imageMode;
	}

	public void setGradient(int clr1, int clr2) {
		PGraphics gradient = Frame.frame0.papplet.createGraphics(width, height);
		gradient.beginDraw();
		for (int i = 0; i < height; i++) {
			float inter = PApplet.map(i, 0, height, 0, 1);
			int c = Frame.frame0.papplet.lerpColor(clr1, clr2, inter);
			gradient.stroke(c);
			gradient.line(0, i, width, i);
		}
		setImage(gradient);
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		update();
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
		update();
	}

	public void setOpacity(int opacity) {
		this.opacity = Math.max(0, Math.min(100, opacity));
		update();
	}

	public void setMargin(int all) {
		marginTop = all;
		marginRight = all;
		marginBottom = all;
		marginLeft = all;
		update();
	}

	public void setMargin(int top_bottom, int left_right) {
		marginTop = top_bottom;
		marginRight = left_right;
		marginBottom = top_bottom;
		marginLeft = left_right;
		update();
	}

	public void setMargin(int top, int right, int bottom, int left) {
		marginTop = top;
		marginRight = right;
		marginBottom = bottom;
		marginLeft = left;
		update();
	}

	public void setMarginTop(int top) {
		marginTop = top;
		update();
	}

	public void setMarginRight(int right) {
		marginRight = right;
		update();
	}

	public void setMarginBottom(int bottom) {
		marginBottom = bottom;
		update();
	}

	public void setMarginLeft(int left) {
		marginLeft = left;
		update();
	}

	public void setPadding(int all) {
		paddingTop = all;
		paddingRight = all;
		paddingBottom = all;
		paddingLeft = all;
		autosize();
		update();
	}

	public void setPadding(int top_bottom, int left_right) {
		paddingTop = top_bottom;
		paddingRight = left_right;
		paddingBottom = top_bottom;
		paddingLeft = left_right;
		autosize();
		update();
	}

	public void setPadding(int top, int right, int bottom, int left) {
		paddingTop = top;
		paddingRight = right;
		paddingBottom = bottom;
		paddingLeft = left;
		autosize();
		update();
	}

	public void setPaddingTop(int top) {
		paddingTop = top;
		autosize();
		update();
	}

	public void setPaddingRight(int right) {
		paddingRight = right;
		autosize();
		update();
	}

	public void setPaddingBottom(int bottom) {
		paddingBottom = bottom;
		autosize();
		update();
	}

	public void setPaddingLeft(int left) {
		paddingLeft = left;
		autosize();
		update();
	}











	/*
	 * STYLE GETTER
	 */

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public int getMinWidth() {
		return minWidth;
	}

	public int getMaxWidth() {
		return maxWidth;
	}

	public int getHeight() {
		return height;
	}

	public int getMinHeight() {
		return minHeight;
	}

	public int getMaxHeight() {
		return maxHeight;
	}

	public int getBackgroundColor() {
		return backgroundColor;
	}

	public int getForegroundColor() {
		return foregroundColor;
	}

	public int getHoverColor() {
		return hoverColor;
	}

	public int getPressedColor() {
		return pressedColor;
	}

	public int getBorderColor() {
		return borderColor;
	}

	public int getBorderWidth() {
		return borderWidth;
	}

	public int getBorderRadius() {
		return borderRadius;
	}

	public String getText() {
		return text;
	}

	public int getFontSize() {
		return fontSize;
	}

	public int getTextAlign() {
		return textAlign;
	}

	public int getTextAlignY() {
		return textAlignY;
	}

	public int getCursor() {
		return cursor;
	}

	public PImage getImage() {
		return image;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public boolean getVisible() {
		return visible;
	}

	public int getOpacity() {
		return opacity;
	}

	public boolean isFocusable() {
		return focusable;
	}

	public boolean getFocused() {
		return focused;
	}

	public int getMarginTop() {
		return marginTop;
	}

	public int getMarginRight() {
		return marginRight;
	}

	public int getMarginBottom() {
		return marginBottom;
	}

	public int getMarginLeft() {
		return marginLeft;
	}

	public int getPaddingTop() {
		return paddingTop;
	}

	public int getPaddingRight() {
		return paddingRight;
	}

	public int getPaddingBottom() {
		return paddingBottom;
	}

	public int getPaddingLeft() {
		return paddingLeft;
	}




	public void animate(String attribute, float aimedValue, double milliseconds) {
		Frame.frame0.animateImpl(attribute, this, aimedValue, milliseconds);
	}








	/*
	 * EVENT METHODS
	 */

	class RMethod {
		Method method;
		Object target;
		Class<?> args;

		RMethod(Method m, Object t, Class<?> args) {
			method = m;
			target = t;
			this.args = args;
		}
	}

	protected RMethod registeredRMethods[];

	protected static final int PRESS_EVENT = 0;
	protected static final int RELEASE_EVENT = 1;
	protected static final int ENTER_EVENT = 2;
	protected static final int EXIT_EVENT = 3;
	protected static final int MOVE_EVENT = 4;
	protected static final int DRAG_EVENT = 5;
	protected static final int WHEEL_EVENT = 6;

	static final int numberMouseListeners = 7;
	protected int totalNumberListeners = numberMouseListeners;

	protected void setupListeners(int number) {
		totalNumberListeners = totalNumberListeners + number;
		registeredRMethods = new RMethod[totalNumberListeners];
	}

	/*
	 * WORKING WITH�EVENTS�IN� ProcessingGUI :
	 * 
	 *
	 *
	 *
	 * The programmer can add certain listeners to his objects. Mouse listeners are
	 * available for all Controls. They can be assigned and given a registered
	 * method with the addMouseListener() method, specifying the type with a string
	 * ("press", "release"...) If no target is specified with the overloaded
	 * addMouseListener() method, papplet will be assumed.
	 * 
	 * How MouseListener works: Frame registers a mouseEvent() method at papplet.
	 * Every Container (also Frame) calls the mouseEvent of all its items, but only
	 * if have the activatedInternalMouseListener property set true. Containers do
	 * that by default and so do buttons, textboxes, sliders etc. (almost
	 * everything) but once the programmer adds a mouseListener it's set to true
	 * anyway. A Control can decide it "chokes" all further mouseEvents by setting
	 * the frames chokeMouseListeners to true (it will be set to false automatically
	 * at the beginning of each frame). This way objects with high z-index, which
	 * will be checked fist can prevent lower objects from getting the mouseEvent.
	 * This is needed for example with menus, spinners, popups etc.
	 *
	 *
	 * Moreover Controls like frame, textbox feature a keylistener or an
	 * itemchanged-listener (listview, menustrip). These listeners are usually
	 * assigned with extra methods like "addItemChangedListener()" etc.
	 * 
	 *
	 * All listener-adding-methods call registerEventRMethod(int number, String
	 * methodName, Object target, Class<?> args) If a listener needs no arguments it
	 * can pass null for args. registerEventRMethod() will try to find a method in
	 * the target that has no args first, even if it should have one, so it doesn't
	 * break down if the programmer forgets to add i.e. "MouseEvent e" or doesn't
	 * need it at all. Then it checks if args are provided at all and if so tries to
	 * find a method in the target. If none is found error will be thrown.
	 *
	 *
	 *
	 *
	 *
	 * CREATING OWN�CONTROLS�WITH�CUSTOM�LISTENERS
	 *
	 * If you create a custom control with custom listeners you have to provide
	 * methods to add them to the object.
	 *
	 *
	 *
	 * You have to honor some essential rules: - all registered methods are stored
	 * in the "registeredRMethods" array. The first 7 (from 0 to 6) methods are
	 * reserved for the mouselisteners: press/release/enter/exit/move/drag/wheel,
	 * DON'T TOUCH�THEM!
	 *
	 * - by default this array is 7 (for mouse listeners) in size - a custom control
	 * needs to recreate this array in the constructor with needed size. This is
	 * done by calling setupListeners(int) in the constructor and passing the number
	 * of ADDITIONAL listeners for this class
	 *
	 * - If your object inherits from any other that "Control" beware that the
	 * parent might already use a listener for an index
	 *
	 * - Create a static final int variable that specifies the index for your
	 * listener (starting at the static Frame.numberMouseListeners) and always use
	 * that one also when handling the method. Default number might change in future
	 * and this should be an easy update.
	 *
	 * - Provide new methods to add AND remove those listeners (best provide an
	 * option with target object, and without making the default target the papplet)
	 *
	 *
	 */

	protected boolean activatedInternalMouseListener = false;

	protected void activateInternalMouseListener() {
		if (!activatedInternalMouseListener) {
			activatedInternalMouseListener = true;
		}
	}

	protected void deactivateInternalMouseListener() {
		if (activatedInternalMouseListener) {
			activatedInternalMouseListener = false;
		}
	}

	public boolean addMouseListener(String type, String methodName) {
		return addMouseListener(type, methodName, Frame.frame0.papplet);
	}

	public boolean addMouseListener(String type, String methodName, Object target) {
		if (!activatedInternalMouseListener)
			activateInternalMouseListener(); // needed for controls that don't register a listener by default (all
											 // containers do);
		switch (type) {
		case "press":
			return registerEventRMethod(PRESS_EVENT, methodName, target, MouseEvent.class);
		case "release":
			return registerEventRMethod(RELEASE_EVENT, methodName, target, MouseEvent.class);
		case "enter":
			return registerEventRMethod(ENTER_EVENT, methodName, target, MouseEvent.class);
		case "exit":
			return registerEventRMethod(EXIT_EVENT, methodName, target, MouseEvent.class);
		case "move":
			return registerEventRMethod(MOVE_EVENT, methodName, target, MouseEvent.class);
		case "drag":
			return registerEventRMethod(DRAG_EVENT, methodName, target, MouseEvent.class);
		case "wheel":
			return registerEventRMethod(WHEEL_EVENT, methodName, target, MouseEvent.class);
		default:
			return false;
		}
	}

	public void removeMouseListener(String type) {
		switch (type) {
		case "press":
			deregisterEventRMethod(PRESS_EVENT);
			break;
		case "release":
			deregisterEventRMethod(RELEASE_EVENT);
			break;
		case "enter":
			deregisterEventRMethod(ENTER_EVENT);
			break;
		case "exit":
			deregisterEventRMethod(EXIT_EVENT);
			break;
		case "move":
			deregisterEventRMethod(MOVE_EVENT);
			break;
		case "drag":
			deregisterEventRMethod(DRAG_EVENT);
			break;
		case "wheel":
			deregisterEventRMethod(WHEEL_EVENT);
			break;
		}
	}

	protected boolean registerEventRMethod(int number, String methodName, Object target, Class<?> args) {
		if (registeredRMethods[number] == null) {
			Class<?> c = target.getClass();
			try { // try with no args
				Method m = c.getMethod(methodName);
				registeredRMethods[number] = new RMethod(m, target, null);
				return true;
			} catch (NoSuchMethodException nsme) {
				try { // try with args
					if (args != null) {
						Method m = c.getMethod(methodName, args);
						registeredRMethods[number] = new RMethod(m, target, args);
						return true;
					} else {
						Frame.frame0.papplet.die("There is no public " + methodName + "() method with the right arguments.");
						registeredRMethods[number] = null;
					}
				} catch (NoSuchMethodException nsme2) {
					Frame.frame0.papplet.die("There is no public " + methodName + "() method with the right arguments.");
					registeredRMethods[number] = null;
				}
			}
		}
		return false;
	}

	protected void deregisterEventRMethod(int number) {
		registeredRMethods[number] = null;
	}

	protected void handleRegisteredEventMethod(int number, Object args) {
		if (registeredRMethods[number] != null) {
			try {
				if (registeredRMethods[number].args != null) {
					registeredRMethods[number].method.invoke(registeredRMethods[number].target, args);
				} else
					registeredRMethods[number].method.invoke(registeredRMethods[number].target);
			} catch (IllegalAccessException ie) {
				ie.printStackTrace();
			} catch (InvocationTargetException te) {
				te.printStackTrace();
			}
		}
	}

	// has to be public
	protected void mouseEvent(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();

		if (visible && enabled) {

			if (x > bounds.X0 && x < bounds.X && y > bounds.Y0 && y < bounds.Y) { // if over element

				switch (e.getAction()) {
				case MouseEvent.PRESS:
					focus();
					Frame.frame0.draggedElement = this;
					Frame.chokeMouseListeners();
					press(e);
					handleRegisteredEventMethod(PRESS_EVENT, e);
					break;
				case MouseEvent.RELEASE:
					release(e);
					Frame.chokeMouseListeners();
					handleRegisteredEventMethod(RELEASE_EVENT, e);
					break;
				case MouseEvent.MOVE:
					move(e);
					handleRegisteredEventMethod(MOVE_EVENT, e);
					break;
				case MouseEvent.DRAG:
					// this code wont be reached anymore for every drag event will be caught by frame
					System.out.println(99999);
					drag(e);
					handleRegisteredEventMethod(DRAG_EVENT, e);
					Frame.chokeMouseListeners();
					break;
				case MouseEvent.WHEEL:
					mouseWheel(e);
					handleRegisteredEventMethod(WHEEL_EVENT, e);
					break;
				}
				if (!pHovered) { // ENTER
					Frame.frame0.papplet.cursor(cursor);
					enter(e);
					handleRegisteredEventMethod(ENTER_EVENT, e);
					pHovered = true;
				}
			} else {
				if (pHovered) { // EXIT
					Frame.frame0.papplet.cursor(0);
					exit(e);
					handleRegisteredEventMethod(EXIT_EVENT, e);
					pHovered = false;
				}
			}
		}
	}

	protected void press(MouseEvent e) {
	}

	protected void release(MouseEvent e) {
	}

	protected void enter(MouseEvent e) {
	}

	protected void exit(MouseEvent e) {
	}

	protected void move(MouseEvent e) {
	}

	protected void drag(MouseEvent e) {
	}

	protected void mouseWheel(MouseEvent e) {
	}

	// methods that will be called when key events occured and this Control is the
	// currently focused element.
	protected void onKeyPress(KeyEvent e) {
	}

	protected void onKeyRelease(KeyEvent e) {
	}

	protected void onKeyTyped(KeyEvent e) {
	}
}
