package pGUI.core;

import processing.core.PApplet;
import processing.event.*;
import pGUI.classes.*;

import java.util.ArrayList;

public class MenuItem extends Control {

	protected ArrayList<Control> items;

	protected ToolStrip dropDown;
	protected MenuItem masterStrip;
	protected boolean open = false;
	protected boolean init = false;

	// internal discerning between a strip header and (sub-) items
	protected int type = MENU_HEADER;
	protected static final int MENU_HEADER = 1;
	protected static final int MENU_ITEM = 2;

	protected Shortcut shortcut;





	public MenuItem() {
		this("");
	}

	public MenuItem(String Text) {
		super();
		height = 25;
		borderWidth = 0;
		fontSize = 15;
		setPadding(0, 10, 4, 10);
		textAlign = 3;
		this.text = Text;

		backgroundColor = 0;
		visualBackgroundColor = 0;
		hoverColor = 1342177280; // just darken menucontainer backgroundcolor a bit
		pressedColor = 1677721600;

		items = new ArrayList<Control>();

		dropDown = new ToolStrip();
		// sync DropDown content with items
		dropDown.content = items;

		dropDown.z = 10;
		activateInternalMouseListener();
	}












	@Override
	protected void render() {
		if (!init) {
			init();
		}
		if (open) {
			visualBackgroundColor = pressedColor;
		}
		pg = Frame.frame0.papplet.createGraphics(width, height);
		pg.beginDraw();
		textAlign = PApplet.LEFT;

		drawDefaultBackground();
		drawDefaultText();

		// draw triangle to indicate that this item has subitems
		if (items.size() > 0 && type == MENU_ITEM) {
			pg.fill(0);
			pg.stroke(0);
			pg.strokeWeight(0);
			pg.triangle(width - 4, height / 2, width - 7, height / 2 + 3, width - 7, height / 2 - 3);
		}

		if (shortcut != null) {
			String textBKP = text;
			textAlign = PApplet.RIGHT; // temporary RIGHT
			text = shortcut.toString();
			drawDefaultText();
			text = textBKP;
		}

		pg.endDraw();
	}




	/*
	 * Menu items need to be initialized once by analyzing if they are a child or
	 * header of a menustrip and make appropriate adjustments
	 */

	protected void init() {
		if (items.size() > 0) {
			Frame.frame0.add(dropDown);
		}
		try {
			@SuppressWarnings("unused")
			ToolStrip pa = ((ToolStrip) parent);
			type = MENU_ITEM;

			hoverColor = 671088660;
			activateInternalMouseListener();
			setPadding(3, 12, 4, 27);
			borderWidth = 0;
			textAlign = PApplet.LEFT;
			//width =((Container)parent).getAvailableWidth();
		} catch (ClassCastException cce) {
			type = MENU_HEADER;
			setMasterStrip(this);
		}
		dropDown.parent = Frame.frame0;
		init = true;
	}


	@Override
	protected void autosize() {
		pg = Frame.frame0.papplet.createGraphics(1, 1);
		pg.beginDraw();
		pg.textSize(fontSize);
		width = (int) (pg.textWidth(text) + paddingLeft + paddingRight);
	}


	/*
	 * Setting master strip recursively (also for the subitems etc). Method is
	 * called at initializing and always when new item added
	 */

	protected void setMasterStrip(MenuItem masterStrip) {
		this.masterStrip = masterStrip;
		for (int i = 0; i < items.size(); i++) {
			((MenuItem) items.get(i)).setMasterStrip(masterStrip);
		}
	}





	/*
	 * close recursively all items from top (first layer menu items) to bottom
	 */

	public void close() {
		if (open) {
			visualBackgroundColor = backgroundColor;

			open = false;
			for (int i = 0; i < items.size(); i++) {
				((MenuItem) items.get(i)).close();
			}
			dropDown.hide();
			update();
		}
	}

	/*
	 * open this strip properly if it has subitems
	 */

	protected void open() {
		if (items.size() > 0) { // has subitems itself -> open them

			// first close all potentially open siblings
			try {
				for (int i = 0; i < ((ToolStrip) parent).content.size(); i++)
					((MenuItem) ((ToolStrip) parent).content.get(i)).close();
			} catch (ClassCastException cce) {
				// ignore casting errors
			}

			open = true;

			// Draw first layer items BENEATH this item
			// and all other layers always NEXT to this item
			if (type == MENU_HEADER) {
				dropDown.x = this.bounds.X0;
				dropDown.y = this.bounds.Y;
			} else {
				dropDown.x = this.bounds.X - 10;
				dropDown.y = this.bounds.Y0;
			}
			// make menustrip (dropdown) visible
			dropDown.show();
		} else { // has no subitems -> close everything

			open = true;
			if (masterStrip != null)
				masterStrip.itemSelected(this);
			visualBackgroundColor = backgroundColor;
		}
	}



	/*
	 * set the displayed shortcut (shortcut has no real effect unless set manually
	 * at Frame)
	 */

	public void setShortcut(Shortcut s) {
		this.shortcut = s;
	}

	// only for masterstrip
	protected void itemSelected(Control c) {
		close();
	}

	@Override
	protected void enter(MouseEvent e) { // when clicked hovering is sufficient for changing the dropdown
		visualBackgroundColor = hoverColor;
		update();
	}

	@Override
	protected void exit(MouseEvent e) {
		visualBackgroundColor = backgroundColor;
		update();
	}


	@Override
	protected void press(MouseEvent e) {
		visualBackgroundColor = pressedColor;

		// if item is menuheader open and close on press
		if (type == MENU_HEADER) {
			if (open) {
				close();
				visualBackgroundColor = hoverColor;
			} else {
				open();
			}
			update();
		}

		Frame.chokeMouseListeners();
	}

	@Override
	protected void release(MouseEvent e) {
		visualBackgroundColor = hoverColor;

		// if item is subitem open and close on release
		if (type == MENU_ITEM) {
			if (open) {
				close();
			} else {
				open();
			}
		}

		if (type == MENU_HEADER) {
			visualBackgroundColor = hoverColor;
		}
		update();
		Frame.chokeMouseListeners();
	}

	@Override
	protected void mouseEvent(MouseEvent e) {
		super.mouseEvent(e);

		// make the entire strip disappear when clicked elsewhere
		if (!Frame.getChokeMouseListeners()) {
			if (e.getAction() == MouseEvent.PRESS && type == MENU_HEADER) {
				close();
			}
		}
	}








	/*
	 * Content Operations
	 */

	// internal adding method
	protected void addItem(int position, Control c) {
		items.add(position, c);

		// !!!parent has to be the dropdown because dropdown is the real parent when
		// drawing
		c.parent = dropDown;

		// c.setParentFrame(this.frame);
		update();
		((MenuItem) c).setMasterStrip(this.masterStrip);
	}

	public void add(Control... controls) {
		for (Control c : controls) {
			addItem(items.size(), c);
		}
		update();
	}

	public void add(String... strings) {
		for (String s : strings) {
			MenuItem newItem = new MenuItem();
			newItem.setText(s);
			addItem(items.size(), newItem);
		}
		update();
	}

	public void insert(int position, Control... controls) {
		for (int i = 0; i < controls.length; i++) {
			addItem(position + i, controls[i]);
		}
	}

	public void clear() {
		items.clear();
		update();
	}

	public void remove(int index) {
		items.remove(index);
		update();
	}

	public void remove(Control c) {
		items.remove(c);
		update();
	}

	public Control[] getItems() {
		Control c[] = new Control[items.size()];
		for (int i = 0; i < items.size(); i++) {
			c[i] = items.get(i);
		}
		return c;
	}
	
	public Control getItem(int index) {
		if(index >= 0 && index < items.size()) {
			return items.get(index);
		}else {
			return null;
		}
	}
}