
package pGUI.core;

import processing.core.*;
import processing.event.*;
import pGUI.classes.*;

import java.util.ArrayList;

public class KeyListener {

	final int CONTROL = 17;
	final int SHIFT = 16;
	final int ALT = 18;
	final int PRESS = 0;
	final int TYPED = 1;
	final int RELEASE = 2;

	public boolean control = false; // true when control is pressed
	public boolean shift = false; // true when shift is pressed
	public boolean alt = false; // true when alt is pressed

	public int previousKeyCode;
	public char previousKey;

	public int currentKeyCode;
	public char currentKey;

	ArrayList<Long> pressedKeys = new ArrayList<Long>(6);

	Frame frame;

	public KeyListener(Frame frame) {
		this.frame = frame;
	}

	public void handleKeyEvent(KeyEvent event, Control c) {

		previousKeyCode = currentKeyCode;
		previousKey = currentKey;

		currentKey = event.getKey();
		currentKeyCode = event.getKeyCode();

		int lastAction = 0;

		if (c.enabled) {
			switch (event.getAction()) {
			case KeyEvent.PRESS:
				c.onKeyPress(event);
				lastAction = PRESS;
				break;
			case KeyEvent.TYPE:
				c.onKeyTyped(event);
				lastAction = TYPED;
				break;
			case KeyEvent.RELEASE:
				c.onKeyRelease(event);
				lastAction = RELEASE;
				break;
			}
		}

		if (currentKey == PApplet.CODED) {
			switch (currentKeyCode) {
			case CONTROL:
				if (lastAction == PRESS) {
					control = true;
				} else if (lastAction == RELEASE) {
					control = false;
				}
				break;
			case SHIFT:
				if (lastAction == PRESS) {
					shift = true;
				} else if (lastAction == RELEASE) {
					shift = false;
				}
				break;
			case ALT:
				if (lastAction == PRESS) {
					alt = true;
				} else if (lastAction == RELEASE) {
					alt = false;
				}
				break;
			}
		}

		// handle shortcuts
		if (lastAction == TYPED) {
		} else if (lastAction == PRESS) {
			Shortcut current = new Shortcut((char) currentKeyCode, control, shift, alt);
			// println("checkshort", (char)keyCode, control, shift, alt, current.equals(sc),
			// (current.hashCode() == sc.hashCode()));
			frame.checkShortcut(current);
		}
	}
}