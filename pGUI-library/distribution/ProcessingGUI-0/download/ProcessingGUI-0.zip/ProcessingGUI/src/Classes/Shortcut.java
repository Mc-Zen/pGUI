package pGUI.classes;

/*
   * 
 * Class for storing keyboard shortcuts. 
 * Can store value for Control-, Shift- and Alt-Key and and an additional key. 
 * 
 * Shortcuts can be created like Shortcut('A', true, true, false) for Ctrl-Shift-A
 * or like Shortcut(A, CONTROL, SHIFT);
 *
 *
 */

public class Shortcut {

	public boolean Control = false;
	public boolean Shift = false;
	public boolean Alt = false;
	public char Key;

	public Shortcut(char Key, boolean Control, boolean Shift, boolean Alt) {
		this.Control = Control;
		this.Shift = Shift;
		this.Alt = Alt;
		this.Key = Key;
	}

	public Shortcut(char Key, int... Modifiers) {
		this.Key = java.lang.Character.toUpperCase(Key);
		for (int modifier : Modifiers) {
			switch (modifier) {
			case 17:
				this.Control = true;
				break;
			case 16:
				this.Shift = true;
				break;
			case 18:
				this.Alt = true;
				break;
			}
		}
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (getClass() != other.getClass())
			return false;

		Shortcut shortcut = (Shortcut) other;

		if (Control == shortcut.Control && Shift == shortcut.Shift && Alt == shortcut.Alt && Key == shortcut.Key) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		int result = (int) Key;
		result = result * 100 + (Control ? 1 : 0);
		result = result * 10 + (Shift ? 1 : 0);
		result = result * 10 + (Alt ? 1 : 0);
		return result;
	}

	public String toString() {
		return (this.Control ? "Ctrl+" : "") + (this.Shift ? "Shift+" : "") + (this.Alt ? "Alt+" : "") + this.Key;
	}
}